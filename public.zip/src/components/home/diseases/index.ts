export { default } from "./Diseases";
