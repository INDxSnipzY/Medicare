export { default } from "./Emergency";
